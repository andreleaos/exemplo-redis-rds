
resource "aws_lambda_function" "api"{
 function_name="movie-api"
 runtime="dotnet8"
 handler="MovieApi.Api::Function::Handler"
 tracing_config{mode="Active"}
}
