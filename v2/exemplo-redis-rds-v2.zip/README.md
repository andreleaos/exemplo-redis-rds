
# AWS .NET Enterprise Patterns

Arquitetura: Route53 -> CloudFront -> WAF -> API Gateway -> Lambda(.NET8) -> Redis -> RDS Proxy -> RDS MySQL

Inclui:
- Clean Architecture
- Terraform
- OpenTelemetry
- Cache Aside
- SNS/SQS
- GitHub Actions
