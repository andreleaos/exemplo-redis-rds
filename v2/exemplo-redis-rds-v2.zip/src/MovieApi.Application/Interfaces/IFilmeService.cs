
using MovieApi.Domain.Entities;
namespace MovieApi.Application.Interfaces;
public interface IFilmeService{Task<Filme?> Obter(int id);}
