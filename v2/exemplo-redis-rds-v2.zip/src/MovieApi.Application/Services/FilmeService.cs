
using MovieApi.Domain.Entities;using MovieApi.Infrastructure.Repositories;
namespace MovieApi.Application.Services;
public class FilmeService{
 RedisRepository _r; FilmeRepository _f;
 public FilmeService(RedisRepository r,FilmeRepository f){_r=r;_f=f;}
 public async Task<Filme?> Obter(int id){
   var cache=await _r.Get(id); if(cache!=null)return cache;
   var db=await _f.Get(id); if(db!=null) await _r.Set(db); return db;
 }}
