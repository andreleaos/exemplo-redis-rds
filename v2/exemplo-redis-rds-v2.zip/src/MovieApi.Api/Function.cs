
using Amazon.Lambda.APIGatewayEvents;
public class Function{
 public Task<APIGatewayProxyResponse> Handler(APIGatewayProxyRequest r)=>
 Task.FromResult(new APIGatewayProxyResponse{StatusCode=200,Body="{\"status\":\"ok\"}"});
}
