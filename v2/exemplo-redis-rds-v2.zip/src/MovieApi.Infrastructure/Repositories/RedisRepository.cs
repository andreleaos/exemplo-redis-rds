
using StackExchange.Redis;using System.Text.Json;using MovieApi.Domain.Entities;
namespace MovieApi.Infrastructure.Repositories;
public class RedisRepository{
 readonly IDatabase _db;
 public RedisRepository(IConnectionMultiplexer c)=>_db=c.GetDatabase();
 public async Task<Filme?> Get(int id){
   var v=await _db.StringGetAsync($"filme:{id}");
   return v.IsNullOrEmpty?null:JsonSerializer.Deserialize<Filme>(v!);
 }
 public Task Set(Filme f)=>_db.StringSetAsync($"filme:{f.Id}",JsonSerializer.Serialize(f),TimeSpan.FromMinutes(30));
}
